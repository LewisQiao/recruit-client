import Vue from 'vue'
import Router from 'vue-router'
// import login from '@/pages/login'
// import layout from '@/pages/layout'
// import index from '@/pages/index'

Vue.use(Router)
const login = r => require.ensure([], () => r(require('@/components/login')), 'login');
const layout = r => require.ensure([], () => r(require('@/components/layout')), 'layout');
const userContorl = r => require.ensure([], () => r(require('@/components/userContorl')), 'userContorl');
const resouContorl = r => require.ensure([], () => r(require('@/components/resouContorl')), 'resouContorl');
const roleContorl = r => require.ensure([], () => r(require('@/components/roleContorl')), 'roleContorl');
const passwContorl = r => require.ensure([], () => r(require('@/components/passwContorl')), 'passwContorl');
const remoteSet = r => require.ensure([], () => r(require('@/components/remoteSet')), 'remoteSet');
const referContorl = r => require.ensure([], () => r(require('@/components/referContorl')), 'referContorl');
const staffMsg = r => require.ensure([], () => r(require('@/components/staffMsg')), 'staffMsg');
const cityMsg = r => require.ensure([], () => r(require('@/components/cityMsg')), 'cityMsg');
const videoContorl = r => require.ensure([], () => r(require('@/components/videoContorl')), 'videoContorl');
const dialContorl = r => require.ensure([], () => r(require('@/components/dialContorl')), 'dialContorl');
const home = r => require.ensure([], () => r(require('@/components/home')), 'home');
export default new Router({
  routes: [
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/',
      name: 'layout',
      component: layout,
      children: [
        {
          path: '',
          name: 'home',
          component: home
        },
        {
          path: '/userContorl',
          name: 'userContorl',
          component: userContorl
        },
        {
          path: '/resouContorl',
          name: 'resouContorl',
          component: resouContorl
        },
        {
          path: '/roleContorl',
          name: 'roleContorl',
          component: roleContorl
        },
        {
          path: '/passwContorl',
          name: 'passwContorl',
          component: passwContorl
        },
        {
          path: '/remoteSet',
          name: 'remoteSet',
          component: remoteSet
        },
        {
          path: '/referContorl',
          name: 'referContorl',
          component: referContorl
        },
        {
          path: '/staffMsg',
          name: 'staffMsg',
          component: staffMsg
        },
        {
          path: '/cityMsg',
          name: 'cityMsg',
          component: cityMsg
        },
        {
          path: '/videoContorl',
          name: 'videoContorl',
          component: videoContorl
        },
        {
          path: '/dialContorl',
          name: 'dialContorl',
          component: dialContorl
        }
      ]
    }
  ]
})
