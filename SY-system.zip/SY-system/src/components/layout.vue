<template>
  <el-container>
    <el-header style="height:90px">
      <common-header></common-header>
    </el-header>
    <el-container>
      <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
        <el-menu :default-openeds="['1']" router>
          <el-submenu index="1">
            <template slot="title">
              <i class="el-icon-message"></i>首页
            </template>
          </el-submenu>
          <el-submenu index="2">
            <template slot="title">
              <i class="el-icon-message"></i>系统设置
            </template>
            <el-menu-item-group>
              <!-- <template slot="title">分组一</template> -->
              <el-menu-item index="userContorl">用户管理</el-menu-item>
              <el-menu-item index="resouContorl">资源管理</el-menu-item>
              <el-menu-item index="roleContorl">角色管理</el-menu-item>
              <el-menu-item index="passwContorl">密码管理</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
          <el-submenu index="3">
            <template slot="title">
              <i class="el-icon-menu"></i>参数设置
            </template>
            <el-menu-item-group>
              <el-menu-item index="remoteSet">远程参数设置</el-menu-item>
              <el-menu-item index="referContorl">会话参数设置</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
          <el-submenu index="4">
            <template slot="title">
              <i class="el-icon-setting"></i>基础信息
            </template>
            <el-menu-item-group>
              <el-menu-item index="staffMsg">客服人员信息</el-menu-item>
              <el-menu-item index="cityMsg">市民信息</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
          <el-submenu index="5">
            <template slot="title">
              <i class="el-icon-setting"></i>日常业务
            </template>
            <el-menu-item-group>
              <el-menu-item index="videoContorl">视频协助</el-menu-item>
              <el-menu-item index="dialContorl">咨询问题</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-aside>
      <el-main>
        <!-- 路由出口 -->
        <el-col :span="24" class="content-wrapper">
          <transition name="fade" mode="out-in">
            <router-view></router-view>
          </transition>
        </el-col>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import commonHeader from "../components/commonHeader.vue";
export default {
  data() {
    return {};
  },
  components: {
    commonHeader
  }
};
</script>
<style>
.el-container {
  height: 100%;
}
.el-aside {
  background-color: #d3dce6;
  color: #333;
  /* text-align: center; */
  line-height: 200px;
}

.el-main {
  background-color: #e9eef3;
  overflow: hidden !important;
}
</style>

