<template>
  <div class="home">
    <div class="home-one">
      <div class="busidata">业务数据</div>
      <div class="busimsg">
        <div class="busimsg-one">
          <div>
            <img src="../../static/images/首页_11.png" alt>
            <p>已接听</p>
          </div>
          <div class="dataNum">
            <span>35</span>次
          </div>
        </div>
        <div class="busimsg-two">
          <div>
            <img src="../../static/images/首页_13.png" alt>
            <p>已解决</p>
          </div>
          <div class="dataNum">
            <span>30</span>次
          </div>
        </div>
        <div class="busimsg-three">
          <div>
            <img src="../../static/images/首页_15.png" alt>
            <p>未解决</p>
          </div>
          <div class="dataNum">
            <span>5</span>次
          </div>
        </div>
      </div>
    </div>
    <div class="home-two">
      <div class="video-one">
        <div class="busidata">常用功能</div>
        <div class="funtion-one">
          <img src="../../static/images/首页_24.png" alt>
          <img src="../../static/images/首页_26.png" alt>
        </div>
      </div>
      <div class="video-two">
        <div class="busidata">当前日期</div>
        <div class="funtion-two">{{date |dateformat('HH:mm')}}</div>
        <div class="funtion-three">{{date |dateformat("MM月DD日")}}{{date|dateweek("dddd")}}</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      date: new Date()
    };
  },
  mounted() {
    let _this = this;
    this.timer = setInterval(() => {
      _this.date = new Date();
    }, 1000);
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
};
</script>
<style scoped>
.home {
  margin: 20px;
  background-color: #f1f1f1;
}
.home-one {
  background-color: #fff;
  margin-bottom: 30px;
}
.busidata {
  border-bottom: 1px solid #e1e1e1;
  padding: 15px 0 15px 30px;
}
.busimsg {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  padding: 40px 0;
}
.busimsg-one,
.busimsg-two,
.busimsg-three {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.busimsg-one p,
.busimsg-two p,
.busimsg-three p {
  text-align: center;
  font-family: "微软雅黑";
  font-size: 18px;
  color: #444444;
}
.dataNum {
  margin-left: 40px;
}
.busimsg-one span {
  font-size: 105px;
  font-family: Arial;
  color: #367fe8;
}
.busimsg-two span {
  font-size: 105px;
  font-family: Arial;
  color: #2fb106;
}
.busimsg-three span {
  font-size: 105px;
  font-family: Arial;
  color: #ff8400;
}
.home-two {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  box-sizing: border-box;
}
.video-one,
.video-two {
  background-color: #fff;
  padding: 30px 80px 80px;
}
.funtion-one img {
  width: 500px;
  height: 195px;
  padding: 20px;
}
.funtion-two {
  background-image: url("../../static/images/首页_21.png");
  background-repeat: no-repeat;
  background-size: cover;
  font-size: 100px;
  font-family: Arial;
  color: #666666;
}
.funtion-three {
  margin-top: 20px;
  font-size: 36px;
  font-family: 微软雅黑;
  color: #9999;
  text-align: center;
}
</style>
