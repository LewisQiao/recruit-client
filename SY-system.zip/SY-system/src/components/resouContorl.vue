<template>
  <div class="resourCon">
    <Content :style="{margin: '20px', background: 'f1f1f1'}">
      <div class="search">
        资源名称
        <Input v-model.trim="text" style="width: 15%;margin-right:30px"/>父资源名称
        <Input v-model="upText" style="width: 15%"/>
        <Button @click="cleanQuery">清除</Button>
        <Button type="primary" @click="checkData">搜索</Button>
      </div>
      <div class="tableList">
        <div class="tableBtn">
          <div class="tableLeft">
            <Button type="primary">
              <img src="../../static/images/下载.png" alt>
              下载
            </Button>
            <Button type="primary">
              <img src="../../static/images/打印.png" alt>
              打印
            </Button>
          </div>
          <div class="tableRight">
            <Button type="success" @click="dialogFormVisible = true">
              <img src="../../static/images/新增.png" alt>
              新增
            </Button>
            <Button type="warning" @click="updatedConfirm">
              <img src="../../static/images/修改.png" alt>
              修改
            </Button>
            <Button type="error" @click="deleteConfirm">
              <img src="../../static/images/删除.png" alt>
              删除
            </Button>
            <!-- 弹出删除框 -->
            <div class="delet">
              <el-dialog title="提示" :visible.sync="centerDialogVisible" width="30%" center>
                <span>确定删除吗？删除之后数据将无法恢复</span>
                <!-- <el-form :model="delform">
                        <el-input v-model="delform.id" v-if="false"/>
                </el-form>-->
                <span slot="footer" class="dialog-footer">
                  <el-button @click="centerDialogVisible = false">取 消</el-button>
                  <el-button type="primary" @click="deletData(tableChecked)">确 定</el-button>
                </span>
              </el-dialog>
            </div>
            <!-- 弹出修改框 -->
            <div class="add">
              <el-dialog title="修改" :visible.sync="updatedialogFormVisible">
                <el-form :model="updateform" :rules="rules" ref="updateform">
                  <el-form-item label="终端设备ID" :label-width="formLabelWidth" prop="text">
                    <el-input v-model.trim="updateform.text" autocomplete="off"></el-input>
                  </el-form-item>
                  <!-- 隐藏id值 -->
                  <el-input v-model="updateform.id" v-if="false"/>
                  <el-form-item label="终端设备名称" :label-width="formLabelWidth" prop="upText">
                    <el-input v-model="updateform.upText" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="IP地址" :label-width="formLabelWidth" prop="url">
                    <el-input v-model="updateform.url" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="远程访问密码" :label-width="formLabelWidth" prop="sort">
                    <el-input v-model="updateform.sort" autocomplete="off"></el-input>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="updatedialogFormVisible = false">取 消</el-button>
                  <el-button type="primary" @click="updateNum">确 定</el-button>
                </div>
              </el-dialog>
            </div>
          </div>
          <!--增加弹出框-->
          <div class="add">
            <el-dialog title="增加" :visible.sync="dialogFormVisible">
              <el-form :model="form" :rules="rules" ref="form">
                <el-form-item label="终端设备ID" :label-width="formLabelWidth" prop="text">
                  <el-input v-model.trim="form.text" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="终端设备名称" :label-width="formLabelWidth" prop="upText">
                  <el-input v-model="form.upText" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="IP地址" :label-width="formLabelWidth" prop="url">
                  <el-input v-model="form.url" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="远程访问密码" :label-width="formLabelWidth" prop="sort">
                  <el-input v-model="form.sort" autocomplete="off"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="remoteNum('form')">确 定</el-button>
              </div>
            </el-dialog>
          </div>
        </div>
        <!-- list列表 -->
        <div class="dataList">
          <el-table
            ref="multipleTable"
            :data="tableData3"
            tooltip-effect="dark"
            style="width: 100%"
            @selection-change="handleSelectionChange"
            :stripe="true"
            border
          >
            <el-table-column type="selection" width="200"></el-table-column>
            <el-table-column label="资源名称">
              <template slot-scope="scope">{{ scope.row.text}}</template>
            </el-table-column>
            <el-table-column prop="upText" label="父资源名称"></el-table-column>
            <el-table-column prop="url" label="访问地址" show-overflow-tooltip></el-table-column>
            <el-table-column prop="sort" label="排序"></el-table-column>
            <el-table-column prop="status" label="状态"></el-table-column>
            <el-table-column prop="icon" label="图标"></el-table-column>
          </el-table>
          <div class="pageNum">
            <!-- <span class="demonstration">显示总数</span> -->
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="page"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalCount"
            ></el-pagination>
          </div>
        </div>
      </div>
    </Content>
  </div>
</template>
<script>
export default {
  data() {
    return {
      page: 1,
      pageSize: 10,
      pageCount: 1,
      totalCount: 0,
      text: "",
      upText: "",
      currentPage4: 4,
      tableChecked: [],
      centerDialogVisible: false,
      updatedialogFormVisible: false,
      value: "",
      menuList: "",
      dialogFormVisible: false,
      form: {
        text: "",
        upText: "",
        url: "",
        sort: "",
        status: ""
      },
      updateform: {
        text: "",
        upText: "",
        url: "",
        sort: "",
        id: "",
        status: ""
      },
      rules: {
        text: [
          { required: true, message: "请输入终端设备ID", trigger: "blur" }
        ],
        upText: [
          { required: true, message: "请输入终端设备名称", trigger: "blur" }
        ],
        url: [{ required: true, message: "请输入IP地址", trigger: "blur" }],
        sort: [
          { required: true, message: "请输入远程访问密码", trigger: "blur" }
        ]
      },
      formLabelWidth: "120px",
      tableData3: [],
      multipleSelection: []
    };
  },
  computed: {
    rotateIcon() {
      return ["menu-icon", this.isCollapsed ? "rotate-icon" : ""];
    },
    menuitemClasses() {
      return ["menu-item", this.isCollapsed ? "collapsed-menu" : ""];
    }
  },
  mounted: function() {
    // this.menu();
    this.checkData(this.page);
  },
  methods: {
    collapsedSider() {
      this.$refs.side1.toggleCollapse();
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      console.log("handleSelectionChange--", val);
      this.tableChecked = val;
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pageSize = val;
      this.checkData(this.page);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.page = val;
      this.checkData(val);
    },
    menu() {
      this.$axios
        .get(
          //  this.$url+"/login",
          "/api/vas/resource/menu"
        )
        .then(function(res) {
          // that.$message("成功", "success");
          // that.$router.push({ path: "/index" });
          // console.log("res=" + res);
          // console.log("res.data=" + res.data);
          // console.log("res.data.code=" + res.data.code);
          // if (res.data.code == 1) {
          //   that.$router.push({ path: "/index" });
          // } else {
          //   // that.$message(res.data.msg, "error");
          //   that.isShowTip = !that.isShowTip;
          // }
          console.log(res.data.t);
          // this.menuList.push(res.data.t);
          this.menuList = res.data.t;
        })
        .catch(function(e) {
          // that.$message("服务错误", "error");
        });
    },
    //新增
    remoteNum(formName) {
      var that = this;
      var text = this.form.text;
      var upText = this.form.upText;
      var url = this.form.url;
      var sort = this.form.sort;
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$axios
            .post(
              "/api/vas/device/add",
              this.$qs.stringify({
                text: text,
                upText: upText,
                url: url,
                sort: sort
              })
            )
            .then(function(res) {
              if (res.data.code == 1) {
                that.dialogFormVisible = false;
                that.$message("操作成功", "success");
              } else {
                that.$message(res.data.msg, "error");
              }
              that.checkData(that.page);
              that.resetForm("form");
            })
            .catch(function(res) {
              that.$message("操作失败", "error");
            });
        } else {
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 搜索查询
    checkData(pageNumber) {
      var that = this;
      var text = this.text;
      var upText = this.upText;
      console.log(upText);
      console.log(text);
      this.$axios
        .post(
          "/api/vas/resource/list",
          this.$qs.stringify({
            text: text,
            upText: upText,
            pageNumber: pageNumber,
            pageSize: this.pageSize
          })
        )
        .then(function(res) {
          if (res.data.code == 1) {
            console.log(res.data.t);
          } else {
            that.$message(res.data.msg, "error");
          }

          that.page = res.data.t.pageNum;
          that.totalCount = res.data.t.count;
          that.pageCount = res.data.t.pageCount;
          that.tableData3 = res.data.t.list;
        })
        .catch(function(res) {
          that.$message("操作失败.", "error");
        });
    },
    // 清除
    cleanQuery() {
      this.text = "";
      this.upText = "";
      this.checkData(this.page);
    },
    deleteConfirm() {
      var selected = this.tableChecked.length;
      if (selected == 0) {
        this.$message("请选择需要删除的数据", "info");
      } else {
        this.centerDialogVisible = true;
      }
    },
    // 批量删除
    deletData() {
      // 遍历出ids
      const length = this.tableChecked.length;
      var ids = "";
      for (let i = 0; i < length; i++) {
        console.log(this.tableChecked[i].id);
        ids += this.tableChecked[i].id + ",";
      }
      console.log(ids);
      var that = this;
      this.$axios
        .post(
          "/api/vas/device/delete",
          this.$qs.stringify({
            ids: ids
          })
        )
        .then(function(res) {
          //  that.dialogFormVisible = false;
          console.log(res);
          if (res.data.code == 1) {
            that.centerDialogVisible = false;
            that.$message("操作成功", "success");
          } else {
            that.$message(res.data.msg, "error");
          }
          that.checkData(that.page);
        })
        .catch(function(res) {
          that.$message("操作失败", "error");
        });
    },
    updatedConfirm() {
      var selectedLength = this.tableChecked.length;
      if (selectedLength == 0) {
        this.$message("请选择需要修改的数据", "info");
      } else if (selectedLength > 1) {
        this.$message("只能选择一条数据", "info");
      } else {
        // 获取选中的数据
        var id, text, upText, url, sort;
        for (let i = 0; i < selectedLength; i++) {
          id = this.tableChecked[i].id;
          text = this.tableChecked[i].text;
          upText = this.tableChecked[i].upText;
          url = this.tableChecked[i].url;
          sort = this.tableChecked[i].sort;
        }
        // 赋值
        this.updateform.id = id;
        this.updateform.text = text;
        this.updateform.upText = upText;
        this.updateform.url = url;
        this.updateform.sort = sort;
        // 显示弹出层
        this.updatedialogFormVisible = true;
      }
    },
    // 修改
    updateNum() {
      var that = this;
      var text = this.updateform.text;
      var upText = this.updateform.upText;
      var url = this.updateform.url;
      var sort = this.updateform.sort;
      var id = this.updateform.id;
      this.$axios
        .post(
          "/api/vas/device/update",
          this.$qs.stringify({
            text: text,
            upText: upText,
            url: url,
            sort: sort,
            id: id
          })
        )
        .then(function(res) {
          if (res.data.code == 1) {
            that.updatedialogFormVisible = false;
            that.$message("操作成功", "success");
          } else {
            that.$message(res.data.msg, "error");
          }
          that.checkData(that.page);
        })
        .catch(function(res) {
          that.$message("操作失败.", "error");
        });
    }
  }
};
</script>
<style scoped>
.search {
  width: 100%;
  padding: 10px 0;
  text-align: center;
  border-bottom: 1px solid rgb(238, 222, 222);
}
.search button {
  margin-left: 20px;
}
.tableList .tableBtn {
  padding: 20px 0;
  overflow: hidden;
}
.tableBtn .tableLeft {
  float: left;
}
.tableLeft button {
  margin-left: 30px;
}
.tableRight button {
  margin-right: 20px;
}
.tableBtn .tableRight {
  float: right;
  padding-right: 30px;
}
.pageNum {
  text-align: center;
  background-color: #ffff;
  padding: 50px 0;
}
button {
  font-size: 16px;
}
button img {
  vertical-align: middle;
}
.ivu-menu-submenu-title img {
  vertical-align: middle;
}

element.style {
  margin-top: 15vh;
}
</style>
<style>
.add .el-dialog__footer {
  text-align: center;
}
.add .el-dialog__header {
  border-bottom: 1px solid #000;
}
.add .el-form {
  display: flex;
  flex-wrap: wrap;
}
.add .el-form-item {
  margin-bottom: 23px;
  margin-left: 67px;
}
/* html,
body,
.layout,
#app,
.remoteCon,
.ivu-layout-has-sider {
  height: 100%;
} */
.ivu-input {
  height: 38px;
}
</style>



