<template>
  <div class="video">
    <Content :style="{margin: '20px', background: 'f1f1f1'}">
      <div class="viedeoMsg">
        <h1>打开远程视频协助窗口并点击连线</h1>
        <h4>即签到进入远程视频协助空闲坐席列表，系统自动分配任务</h4>
        <div class="button">
          <el-button type="primary">远程视频协助窗口</el-button>
        </div>
        <div class="remotevideo">
          <img src="../../static/images/视频协助_03.png" alt>
        </div>
      </div>
    </Content>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.video {
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
}
.viedeoMsg h1,
.viedeoMsg h4 {
  text-align: center;
}
.viedeoMsg h1 {
  font-size: 35px;
  font-family: "微软雅黑";
  color: #377ee8;
  margin-top: 130px;
}
.viedeoMsg h4 {
  font-size: 24px;
  font-family: "微软雅黑";
  color: #666666;
}
.button {
  margin: auto;
  text-align: center;
}
button {
  width: 480px;
  height: 80px;
  background-color: #377ee8;
  font-family: "微软雅黑";
  font-size: 30px;
  color: #fff;
  border-radius: 10px;
  margin-top: 50px;
}
.remotevideo {
  margin-top: 60px;
}
img {
  width: 880px;
  height: auto;
}
</style>

