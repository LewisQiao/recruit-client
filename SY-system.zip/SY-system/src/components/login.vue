<template>
  <el-container>
    <el-header style="height:120px">
      <div class="log">
        <img src="../../static/images/yccssj_01.png" alt>
      </div>
    </el-header>
    <el-main>
      <div class="login">
        <!-- 登录表单 -->
        <h1>远程可视化协助系统</h1>
        <el-form
          :model="loginform"
          status-icon
          :rules="rules"
          ref="loginform"
          label-width="100px"
          class="demo-ruleForm"
        >
          <!-- 用户名 -->
          <el-form-item label="用户" prop="username">
            <el-input
              type="text"
              v-model="loginform.username"
              autocomplete="off"
              style="width: 100%;"
            ></el-input>
          </el-form-item>
          <!-- 密码 -->
          <el-form-item label="密码" prop="password">
            <el-input
              type="password"
              v-model="loginform.password"
              autocomplete="off"
              style="width: 100%;"
            ></el-input>
          </el-form-item>
          <div class="tip" v-if="isShowTip">
            <img src="../../static/images/提示_03.png" alt>
            <a href="#">{{msg}}</a>
          </div>
          <!-- 登录 -->
          <el-form-item>
            <el-button type="primary" @click="submitForm('loginform')" style="width: 100%;">登录</el-button>
          </el-form-item>
          <!-- 记住密码 -->
          <el-form-item label="记住密码" prop="delivery">
            <el-switch v-model="loginform.delivery"></el-switch>
          </el-form-item>
        </el-form>
      </div>
    </el-main>
    <el-footer></el-footer>
  </el-container>
</template>
<script>
export default {
  data() {
    return {
      msg: "",
      isShowTip: false,
      //登录表单数据
      loginform: {
        username: "",
        password: ""
      },
      //验证表单数据
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 4, max: 12, message: "长度在 4 到12个字符", trigger: "blur" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 5, max: 12, message: "长度在 5 到12个字符", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      var that = this;
      this.$refs[formName].validate(valid => {
        if (valid) {
          console.log(this.loginform.username, this.loginform.password);
          this.$axios
            .post(
              //  this.$url+"/login",
              "/api/vas/login",
              this.$qs.stringify({
                username: this.loginform.username,
                password: this.loginform.password
              })
            )
            .then(function(res) {
              // that.$message("成功", "success");
              // that.$router.push({ path: "/index" });
              // console.log("res=" + res);
              // console.log("res.data=" + res.data);
              // console.log("res.data.code=" + res.data.code);
              if (res.data.code == 1) {
                // console.log(res.data.t)
                // sessionStorage.setItem("useId",that.loginform.username);
                // sessionStorage.setItem("token",res.data.t)
                that.$router.push({ path: "/" });
              } else {
                // that.$message(res.data.msg, "error");
                that.msg = res.data.msg;
                that.isShowTip = true;
              }
            })
            .catch(function(e) {
              that.$message("服务错误", "error");
            });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
    // submitForm() {
    //   this.$notify.success({
    //     message: "用户名或者密码有错误"
    //   });
    // }
  }
};
</script>
<style scoped>
.el-header {
  display: flex;
  align-items: center;
}
.el-main {
  width: 100%;
  height: 600px;
  background-image: url("../../static/images/loginbg.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-color: red;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding-right: 100px;
  box-sizing: border-box;
}
.login {
  width: 400px;
  height: 450px;
  background-color: #ffff;
}
.el-form {
  width: 83%;
}
.el-form-item {
  margin-top: 30px;
}
.login h1 {
  padding-top: 20px;
  padding-left: 100px;
  padding-bottom: 20px;
}
.tip {
  font-size: 14px;
  margin-left: 100px;
  background-color: pink;
}
.tip a {
  color: black;
}
.tip img {
  vertical-align: middle;
}
</style>
