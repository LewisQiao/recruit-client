<template>
  <div class="tipmenu">
    <ul>
      <li>
        <a href="#">CSV</a>
      </li>
      <li>
        <a href="#">Excel</a>
      </li>
      <li>
        <a href="#">PDF</a>
      </li>
    </ul>
    <div class="out"></div>
    <div class="in"></div>
  </div>
</template>
<style scoped>
.tipmenu {
  width: 160px;
  height: 110px;
  border: 1px solid #387ee8;
  border-radius: 15px;
  background-color: #fff;
  padding: 0 20px;
  position: relative;
}
.tipmenu li {
  border-bottom: 1px solid #e1e1e1;
  height: 35px;
  line-height: 35px;
  text-align: center;
  color: #387ee8;
}
.tipmenu li:last-child {
  border: none;
}
.out,
.in {
  position: absolute;
  width: 0;
  height: 0px;
}
.out {
  border: 25px solid transparent;
  border-bottom-color: #387ee8;
  top: -50px;
  left: 35%;
}
.in {
  border: 25px solid transparent;
  border-bottom-color: #fff;
  top: -50px;
  left: 35%;
}
</style>
