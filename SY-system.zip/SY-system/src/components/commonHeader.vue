
<template>
  <div class="header">
    <div class="log">
      <img src="../../static/images/yccssj_01.png">
    </div>
    <div class="set">
      <div class="admin">
        <img src="../../static/images/yccssj_04.png" style="vertical-align:middle">
        <a href="#">Hi，管理员</a>
      </div>
      <div class="exit" @click="logout">
        <img src="../../static/images/yccssj_07.png" style="vertical-align:middle">
        <a href="#">退出</a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    logout() {
      var _this = this;
      this.$confirm("确认退出吗？", "提示", {
        //type: 'warning'
      })
        .then(() => {
          sessionStorage.removeItem("user");
          _this.$router.push("/login");
        })
        .catch(() => {});
    }
  }
};
</script>
<style scoped>
.header {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 16px;
}
.header .set {
  display: flex;
  justify-content: space-between;
  align-items: center;
  line-height: 90px;
}
.set .admin,
.set .exit {
  margin-right: 15px;
  padding-right: 20px;
}
.exit img,
.admin img {
  margin-right: 10px;
}
/* .admin:before {
  content: "";
  width: 1px;
  height: 35px;
  background-color: #000;
  position: absolute;
  left: 92%;
  top: 30px;
} */
</style>


